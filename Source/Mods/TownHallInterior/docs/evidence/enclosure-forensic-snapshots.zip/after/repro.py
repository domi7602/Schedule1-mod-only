"""Read-only, pinned TownHall enclosure geometry repro. Python stdlib + installed .NET 8.
Run: python repro.py [--assert-closed] [--refresh]
Writes only beside this script; never starts the game, deploys, or loads Blender.
Geometry comes from actual copied production C# methods, not reimplemented plans.
Unity visibility is a source-guarded model, not execution of Unity/URP or game acceptance.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Users/pc/Schedule1-mod-only')
MOD = REPO / 'Source/Mods/TownHallInterior'
PURE = ['RoomPlan.cs', 'PublicEntrance.cs', 'FurniturePlan.cs', 'FacadePortal.cs', 'NativeSceneSwap.cs']
WIRES = ['UnityRoomSink.cs', 'PublicHallHost.cs', 'VanillaFurnishings.cs']
INPUTS = ['src/' + name for name in PURE + WIRES] + ['assets/native-facade.json', 'assets/native-furniture.json']
PROJECT = '''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><LangVersion>12</LangVersion><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="Program.cs"/>%s</ItemGroup></Project>'''
PROGRAM = '''using TownHallInterior;
using System.Text.Json;
var input = args[0];
var facade = FacadePortal.Read(File.ReadAllBytes(Path.Combine(input, "assets/native-facade.json")));
var furniture = FurniturePlan.Read(File.ReadAllBytes(Path.Combine(input, "assets/native-furniture.json")));
var frame = FurniturePlan.PrepareAsset(furniture.Assets.Single(a => a.Key == "door-frame"));
var placement = FurniturePlan.Create(furniture).Single(a => a.Key == "door-frame");
File.WriteAllText(args[1], JsonSerializer.Serialize(new {
    room = RoomPlan.Create(), interior = PublicEntrance.CreateInterior(), shell = FurniturePlan.CreateShell(),
    frame, placement, facade = facade.Sources.Select(FacadePortal.Cut).ToArray(), originalFacade = facade.Sources,
    portalMin = FacadePortal.Minimum, portalMax = FacadePortal.Maximum,
    floorTop = PublicEntrance.FloorTop, upper = RoomPlan.Upper
}));
'''

def run(cmd):
    result = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout


def export(refresh=False):
    snapshot = ROOT / 'input'
    manifest = ROOT / 'source-hashes.json'
    if refresh or not manifest.exists():
        rows = {}
        for relative in INPUTS:
            source = MOD / relative
            data = source.read_bytes()
            dest = snapshot / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            rows[relative] = hashlib.sha256(data).hexdigest()
        manifest.write_text(json.dumps(rows, indent=2), encoding='utf-8')
    pinned = json.loads(manifest.read_text(encoding='utf-8'))
    for relative, expected in pinned.items():
        if hashlib.sha256((snapshot / relative).read_bytes()).hexdigest() != expected:
            raise ValueError('Modified snapshot: ' + relative)
    for name, text in [('Repro.csproj', PROJECT % ''.join('<Compile Include="input/src/%s"/>' % n for n in PURE)), ('Program.cs', PROGRAM)]:
        (ROOT / name).write_text(text, encoding='utf-8')
    run(['dotnet', 'run', '--project', str(ROOT / 'Repro.csproj'), '--configuration', 'Release', '-p:S1NoDeploy=true', '--', str(snapshot), str(ROOT / 'geometry.json')])
    changed = [relative for relative, h in pinned.items() if hashlib.sha256((MOD / relative).read_bytes()).hexdigest() != h]
    data = json.loads((ROOT / 'geometry.json').read_text(encoding='utf-8'))
    return data, changed


def add(a, b): return tuple(x + y for x, y in zip(a, b))
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def mul(a, t): return tuple(x * t for x in a)
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def unit(a): return mul(a, 1 / math.sqrt(dot(a, a)))
def rounded(a): return [round(x, 6) for x in a]


def box(name, lo, hi, solid=False):
    return {'Name': name, 'X': (lo[0]+hi[0])/2, 'Y': (lo[1]+hi[1])/2, 'Z': (lo[2]+hi[2])/2, 'Width': hi[0]-lo[0], 'Height': hi[1]-lo[1], 'Depth': hi[2]-lo[2], 'Solid': solid, 'Style': 1}


def bounds(b):
    mid = (b['X'], b['Y'], b['Z'])
    size = (b['Width'], b['Height'], b['Depth'])
    return tuple(mid[i] - size[i]/2 for i in range(3)), tuple(mid[i] + size[i]/2 for i in range(3))


def box_hit(b, origin, direction, distance=100):
    lo, hi = bounds(b)
    enter, leave, face = -math.inf, math.inf, None
    for i in range(3):
        if abs(direction[i]) < 1e-10:
            if origin[i] < lo[i]-1e-8 or origin[i] > hi[i]+1e-8:
                return None
        else:
            t1, t2 = (lo[i]-origin[i])/direction[i], (hi[i]-origin[i])/direction[i]
            near, far = min(t1, t2), max(t1, t2)
            if near > enter:
                enter, face = near, ['x', 'y', 'z'][i] + ('min' if t1 < t2 else 'max')
            leave = min(leave, far)
            if leave < enter-1e-8:
                return None
    if leave < 1e-7 or enter > distance:
        return None
    t = max(enter, 0)
    return {'name': b['Name'], 't': round(t, 6), 'point': rounded(add(origin, mul(direction, t))), 'face': face, 'inside_at_origin': enter < 0}


def triangles(meshes, prefix='native', translation=(0, 0, 0)):
    result = []
    for m in meshes:
        for sm, inds in enumerate(m['Submeshes']):
            for offset in range(0, len(inds), 3):
                vertices = [m['Vertices'][i] for i in inds[offset:offset+3]]
                points = [add(v[:3], translation) for v in vertices]
                normal = cross(sub(points[1], points[0]), sub(points[2], points[0]))
                if dot(normal, normal) < 1e-18:
                    continue
                authored = tuple(sum(v[i] for v in vertices)/3 for i in range(3, 6))
                result.append({'name': prefix + ':' + m.get('Path', m.get('SourcePath', '?')), 'submesh': sm, 'triangle': offset//3, 'points': points, 'normal': unit(normal), 'authored': authored})
    return result


def triangle_hit(tri, origin, direction, distance=100):
    a, b, c = tri['points']
    e1, e2 = sub(b, a), sub(c, a)
    p = cross(direction, e2)
    det = dot(e1, p)
    if abs(det) < 1e-10:
        return None
    s = sub(origin, a)
    u = dot(s, p) / det
    if u < -1e-8 or u > 1+1e-8:
        return None
    q = cross(s, e1)
    v = dot(direction, q)/det
    if v < -1e-8 or u+v > 1+1e-8:
        return None
    t = dot(e2, q)/det
    if t <= 1e-7 or t > distance:
        return None
    return {'name': tri['name'], 'submesh': tri['submesh'], 'triangle': tri['triangle'], 't': round(t, 6), 'point': rounded(add(origin, mul(direction, t))), 'normal': rounded(tri['normal']), 'normal_dot_ray': round(dot(tri['normal'], direction), 6), 'authored_dot_ray': round(dot(tri['authored'], direction), 6), 'triangle_vertices': [rounded(p) for p in tri['points']]}


def scene(data):
    source = (ROOT / 'input/src/UnityRoomSink.cs').read_text(encoding='utf-8')
    assert 'box.Name.StartsWith("west-") || box.Name.StartsWith("upper-")' in source
    assert 'box.Name is "east" or "south" or "north"' in source
    assert 'child.GetComponent<Renderer>().enabled = false;' in source
    # Deliberately source-guarded visibility adapter; not a Unity execution claim.
    visible = [b for b in data['room'] if not (b['Name'].startswith(('west-', 'upper-')) or b['Name'] in ('east', 'south', 'north'))]
    visible += data['interior'] + data['shell']
    hidden = [b for b in data['room'] if b not in visible]
    placement = data['placement']
    assert placement['Yaw'] == 0
    frame = triangles(data['frame']['Parts'], 'frame', (placement['X'], placement['Y'], placement['Z']))
    facade = triangles(data['facade'])
    return visible, hidden, frame, facade


def probe(name, origin, direction, visible, hidden, frame, facade, distance=100):
    direction = unit(direction)
    hits = lambda rows: sorted((h for h in rows if h is not None), key=lambda h: h['t'])
    owned = hits(box_hit(b, origin, direction, distance) for b in visible)
    invisible = hits(box_hit(b, origin, direction, distance) for b in hidden)
    frame_hits = hits(triangle_hit(t, origin, direction, distance) for t in frame)
    native_hits = hits(triangle_hit(t, origin, direction, distance) for t in facade)
    front = [h for h in native_hits if h['normal_dot_ray'] < -1e-7]
    return {'name': name, 'origin': origin, 'direction': rounded(direction), 'max_distance': distance,
            'owned_visible': owned[:4], 'hidden_collider': invisible[:4], 'frame': frame_hits[:4],
            'native_two_sided': native_hits[:6], 'native_front_facing': front[:4],
            'open_through_model': not owned and not frame_hits and not front}


def proposal(data):
    """Render-only illustrative closure; never applied to production or accepted colliders."""
    boxes = []
    # Corner fill is outside the existing inward wall faces: keep usable footprint unchanged.
    for x1, x2, side in [(54.95, 55, 'west'), (62.4, 62.45, 'east')]:
        for z1, z2, end in [(21.4, 21.6, 'south'), (40.4, 40.6, 'north')]:
            boxes.append(box('proposal-corner-' + side + '-' + end, (x1, 1.5, z1), (x2, 4.48, z2)))
    # Upper wall bottoms overlap the EG crowns; west opening is kept at 4.55.
    boxes += [box('proposal-upper-west-south', (54.75, 4.47, 21.4), (54.95, 8.13, 30.04)),
              box('proposal-upper-west-north', (54.75, 4.47, 31.96), (54.95, 8.13, 40.6)),
              box('proposal-upper-west-header', (54.75, 4.55, 30.04), (54.95, 8.13, 31.96)),
              box('proposal-upper-east', (62.45, 4.47, 21.4), (62.65, 8.13, 40.6)),
              box('proposal-upper-south', (54.75, 4.47, 21.4), (62.65, 8.13, 21.6)),
              box('proposal-upper-north', (54.75, 4.47, 40.4), (62.65, 8.13, 40.6)),
              box('proposal-upper-ceiling', (54.75, 8.05, 21.4), (62.65, 8.13, 40.6)),
              box('proposal-reveal-south', (54.3, 1.41, 29.95), (54.95, 4.85, 30.04)),
              box('proposal-reveal-north', (54.3, 1.41, 31.96), (54.95, 4.85, 32.05)),
              box('proposal-reveal-header', (54.3, 4.55, 30.04), (54.95, 4.85, 31.96))]
    # Prefer thickening the four EXISTING decorative ceiling panels over new overlays.
    # Their undersides, XZ footprint and stair hole do not move; tops meet existing support Y=4.75.
    # This also closes the 4.48..4.55 header gap at X=54.95 and gives real slab-edge returns.
    for slab in data['shell']:
        if slab['Name'].startswith('ceiling-'):
            lo, hi = bounds(slab)
            boxes.append(box('proposal-panel-' + slab['Name'], lo, (hi[0], data['upper'], hi[2])))
    return boxes


def candidate_visible(visible, proposed):
    return [b for b in visible if not b['Name'].startswith('ceiling-')] + proposed


def analyze(data, changed):
    visible, hidden, frame, facade = scene(data)
    probes = [
        ('corner-west-south', (55.035, 3, 23), (-.04, 0, -1)),
        ('corner-east-south', (62.365, 3, 23), (.04, 0, -1)),
        ('corner-west-north', (55.035, 3, 39), (-.04, 0, 1)),
        ('corner-east-north', (62.365, 3, 39), (.04, 0, 1)),
        ('stair-up', (61.4, 4, 27), (0, 1, 0)),
        ('upper-up', (58.7, 6.3, 31), (0, 1, 0)),
        ('upper-west', (58.7, 6.3, 31), (-1, 0, 0)),
        ('upper-east', (58.7, 6.3, 31), (1, 0, 0)),
        ('upper-south', (58.7, 6.3, 31), (0, 0, -1)),
        ('upper-north', (58.7, 6.3, 31), (0, 0, 1)),
        ('entry-below-lintel-above-ceiling', (52.8, 3.1, 31), (1, (4.515-3.1)/(54.95-52.8), 0)),
        ('entry-above-lintel', (52.8, 3.1, 31), (1, (4.86-3.1)/(54.75-52.8), 0)),
        ('entry-beside-lintel-south', (52.8, 3.1, 31), (1, (4.6-3.1)/(54.75-52.8), (30.02-31)/(54.75-52.8))),
        ('entry-beside-lintel-north', (52.8, 3.1, 31), (1, (4.6-3.1)/(54.75-52.8), (31.98-31)/(54.75-52.8))),
        ('entry-low-central-control', (53, 2.5, 31), (1, 0, 0)),
        ('entry-header-control', (53, 4.65, 31), (1, 0, 0)),
        ('upper-down-support', (58.7, 5.5, 31), (0, -1, 0)),
    ]
    current = [probe(n, o, d, visible, hidden, frame, facade) for n, o, d in probes]
    proposed = proposal(data)
    after = [probe(n, o, d, candidate_visible(visible, proposed), hidden, frame, facade) for n, o, d in probes]
    frame_bounds = {'min': rounded(tuple(min(t['points'][v][axis] for t in frame for v in range(3)) for axis in range(3))), 'max': rounded(tuple(max(t['points'][v][axis] for t in frame for v in range(3)) for axis in range(3)))}
    checks = []
    for before, later in zip(current, after):
        if before['name'].startswith('corner-') or before['name'].startswith('upper-') and before['name'] != 'upper-down-support' or before['name'] == 'stair-up' or before['name'].startswith(('entry-below-', 'entry-above-', 'entry-beside-')):
            checks.append({'name': before['name'], 'current_closed': not before['open_through_model'], 'proposal_closed': not later['open_through_model']})
    # A floor-looking-down ray currently sees the back/top of the EG ceiling below the collider.
    before_floor = next(p for p in current if p['name'] == 'upper-down-support')
    after_floor = next(p for p in after if p['name'] == 'upper-down-support')
    checks.append({'name': 'upper-rendered-floor-matches-support',
        'current_closed': bool(before_floor['owned_visible']) and abs(before_floor['owned_visible'][0]['point'][1]-data['upper']) < .001,
        'proposal_closed': bool(after_floor['owned_visible']) and abs(after_floor['owned_visible'][0]['point'][1]-data['upper']) < .001})
    def overlaps(b, lo, hi):
        bmin, bmax = bounds(b)
        # Source boxes are float32 centers/sizes; their reconstructed faces carry a few micro-units of cancellation.
        return all(min(bmax[i], hi[i])-max(bmin[i], lo[i]) > 1e-5 for i in range(3))
    entrance_volume = ((54.18, 1.41, 30.04), (54.95, 4.55, 31.96))
    stair_volume = ((60.7, 4.4, 24), (62.1, 7.25, 29.6))
    safety = {
        'proposal_render_only': all(not b['Solid'] for b in proposed),
        'proposal_entering_portal': [b['Name'] for b in proposed if overlaps(b, *entrance_volume)],
        'proposal_entering_stair_void': [b['Name'] for b in proposed if overlaps(b, *stair_volume)],
        'entrance_volume_checked': entrance_volume,
        'stair_volume_checked': stair_volume,
        'overlap_tolerance': 1e-5,
        'ceiling_undersides_preserved': all(abs(bounds(b)[0][1] - bounds(next(s for s in data['shell'] if s['Name'] == b['Name'].removeprefix('proposal-panel-')))[0][1]) < 1e-8 for b in proposed if b['Name'].startswith('proposal-panel-')),
    }
    return {'scope': 'Pinned production plans + exact extracted facade/frame triangles; source-guarded visibility; no native runtime, no complete scene inventory, no shader/LOD execution. Native hit facing uses original winding; outward-facing hits are conditional backface-cull evidence.',
            'live_sources_changed_since_snapshot': changed, 'portal_min': data['portalMin'], 'portal_max': data['portalMax'], 'floor_top': data['floorTop'], 'frame_bounds': frame_bounds,
            'source_hashes': json.loads((ROOT/'source-hashes.json').read_text(encoding='utf-8')),
            'native_triangle_count': len(facade), 'native_winding_agrees_authored_normals': sum(dot(t['normal'], t['authored']) > 0 for t in facade),
            'visible_box_bounds': [{'name': b['Name'], 'lo': rounded(bounds(b)[0]), 'hi': rounded(bounds(b)[1])} for b in visible if not b['Name'].startswith('step-')],
            'current': current, 'proposed': after, 'proposal_boxes': proposed, 'regressions': checks, 'proposal_safety': safety}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--refresh', action='store_true', help='Explicitly replace scratch snapshot from current repository sources')
    parser.add_argument('--assert-closed', action='store_true', help='Exit 1 if the pinned current enclosure has any model leak')
    parser.add_argument('--verify-evidence', action='store_true', help='Require the pinned red baseline, green proposal, clear portal/void and positive ray controls')
    args = parser.parse_args()
    data, changed = export(args.refresh)
    report = analyze(data, changed)
    (ROOT/'report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('Pinned snapshot; live-source differences:', changed)
    print('Frame bounds:', report['frame_bounds'])
    print('Native triangles / aligned authored normals:', report['native_triangle_count'], report['native_winding_agrees_authored_normals'])
    for row in report['regressions']:
        print(('PASS' if row['current_closed'] else 'RED'), row['name'], 'candidate-model=' + ('PASS' if row['proposal_closed'] else 'RED'))
    for row in report['current']:
        print(row['name'], json.dumps({k: row[k][:1] for k in ('owned_visible', 'hidden_collider', 'frame', 'native_two_sided', 'native_front_facing')}, separators=(',', ':')))
    print('Full bounded evidence:', ROOT/'report.json')
    if args.verify_evidence:
        assert len(report['regressions']) == 15, 'Unexpected repro coverage'
        assert all(not r['current_closed'] for r in report['regressions']), 'Pinned repro no longer red'
        assert all(r['proposal_closed'] for r in report['regressions']), 'Proposal model still leaks'
        safety = report['proposal_safety']
        assert safety['proposal_render_only'] and not safety['proposal_entering_portal'] and not safety['proposal_entering_stair_void'], safety
        control = next(r for r in report['current'] if r['name'] == 'entry-header-control')
        assert control['frame'] and control['native_front_facing'] and control['owned_visible']
        visible, hidden, frame, facade = scene(data)
        assert safety['ceiling_undersides_preserved'], safety
        short = probe('open-aperture', (53, 2.5, 31), (1, 0, 0), candidate_visible(visible, proposal(data)), hidden, frame, facade, distance=2.0)
        assert short['open_through_model'], short
        unit_box = box('unit-cube', (-1, -1, -1), (1, 1, 1))
        assert box_hit(unit_box, (0, 0, -3), (0, 0, 1))['point'] == [0, 0, -1]
        assert box_hit(unit_box, (2, 0, -3), (0, 0, 1)) is None
        print('EVIDENCE VERIFIED: red baseline, candidate closure, exact portal/void safety and positive/negative controls.')
    if args.assert_closed and any(not row['current_closed'] for row in report['regressions']):
        return 1
    return 0

if __name__ == '__main__':
    sys.exit(main())
