using System;
using System.Collections.Generic;
using Il2CppScheduleOne.Map;
using Il2CppScheduleOne.PlayerScripts;
using MelonLoader;
using UnityEngine;

namespace TownHallInterior;

// Builds inactive, then publishes the collider opening and attributed facade replacements.
// Native shared meshes and the NPC building identity are never changed.
internal sealed class PublicHallHost : IDisposable
{
    private readonly UnityRoomSink _sink;
    private readonly List<(Collider Collider, bool Enabled)> _journal = new();
    private readonly List<(Renderer Renderer, bool Enabled, bool ForcedOff)> _renderers = new();
    private readonly List<Material> _materials = new();
    private NativeFacadeSwap? _facade;
    private VanillaFurnishings? _furnishings;
    private Transform? _south;
    private Transform? _north;
    private bool _savedCanKnock;
    private bool _savedUsable;
    private Il2CppScheduleOne.Doors.StaticDoor? _nativeDoor;
    private bool _doorFlagsSaved;
    private GameObject? _intObj;
    private bool _intObjWasActive;
    private float _open;
    private bool _disposed;
    private CleanupJournal? _cleanup;
    internal bool CleanupComplete => _disposed;

    private PublicHallHost(UnityRoomSink sink) => _sink = sink;

    internal static PublicHallHost? TryOpen(IRoomSink sink)
    {
        if (sink is not UnityRoomSink room || room.Root == null) return null;
        var host = new PublicHallHost(room);
        try
        {
            var building = Find(NativeSceneSwap.BuildingPath)
                ?? throw new InvalidOperationException("Town Hall building is missing");
            host._facade = NativeFacadeSwap.Prepare(room.Root, building);
            host.CreateLeaves();
            host.Tick(0); // place leaves before the root can become visible/collidable
            if (!host.SwapColliders()) { host.Dispose(); host.Dispose(); return null; }
            host.HideDoorMesh();
            host.SuppressPlayerKnock();
            host._facade.Publish();
            room.Publish();
            host.Furnish();
            MelonLogger.Msg("TownHallInterior: hall and geometric facade opening published; player knock disabled.");
            return host;
        }
        catch (Exception ex)
        {
            MelonLogger.Warning("TownHallInterior public hall refused: " + ex.Message);
            host.Dispose(); host.Dispose(); // One bounded retry of failed steps only.
            return null;
        }
    }

    private void Furnish()
    {
        _furnishings = new VanillaFurnishings();
        try { _furnishings.PrepareAndPublish(_sink.Root!); }
        catch (Exception ex)
        {
            // Optional furnishing failure must not close the accepted public entrance.
            try { MelonLogger.Warning("TownHallInterior furniture unavailable; entrance retained: " + ex.Message); }
            catch { }
            _furnishings.Dispose();
            _furnishings.Dispose();
            // Retain incomplete cleanup for the host's scene-exit retry.
        }
    }

    internal void Tick(float deltaSeconds)
    {
        if (_disposed || _cleanup != null || _south == null || _north == null) return;
        _open = PublicEntrance.MoveLeaf(_open, PlayerAtDoor(), deltaSeconds);
        _south.localPosition = new Vector3(54.12f, PublicEntrance.LeafCenterY, 30.52f - _open * 1.05f);
        _north.localPosition = new Vector3(54.12f, PublicEntrance.LeafCenterY, 31.48f + _open * 1.05f);
    }

    public void Dispose()
    {
        if (_disposed) return;
        Restore();
    }

    private bool SwapColliders()
    {
        var building = Find(NativeSceneSwap.BuildingPath);
        var npc = building?.GetComponent<NPCEnterableBuilding>();
        if (building == null || npc == null ||
            !string.Equals(npc.BakedGUID, NativeSceneSwap.BuildingGuid, StringComparison.OrdinalIgnoreCase))
        {
            MelonLogger.Warning("TownHallInterior: Town Hall path or GUID did not match.");
            return false;
        }
        var guidCount = CountGuid(NativeSceneSwap.BuildingGuid);
        if (guidCount != 1)
        {
            MelonLogger.Warning("TownHallInterior: expected one Town Hall GUID, found " + guidCount);
            return false;
        }

        var seen = new List<NativeColliderObservation>();
        foreach (var expected in NativeSceneSwap.Candidates)
        {
            var go = Find(expected.Path);
            var collider = MatchingCollider(go, expected.Kind);
            if (go == null)
            {
                MelonLogger.Warning("TownHallInterior: object missing at " + expected.Path);
                return false;
            }
            if (collider == null)
            {
                MelonLogger.Warning("TownHallInterior: " + expected.Kind + " missing at " + expected.Path);
                return false;
            }
            var bounds = collider.bounds;
            seen.Add(new NativeColliderObservation(expected.Path, expected.Kind,
                bounds.min.x, bounds.min.y, bounds.min.z, bounds.max.x, bounds.max.y, bounds.max.z,
                collider.enabled, collider.isTrigger, ColliderCount(go)));
        }
        var inspection = NativeSceneSwap.Inspect(new NativeSceneObservation(
            NativeSceneSwap.BuildingPath, NativeSceneSwap.BuildingGuid, seen, 1));
        if (!PublicEntrance.ColliderSwapAllowed(inspection))
        {
            MelonLogger.Warning("TownHallInterior: collider identity refused: " + inspection.Reason);
            return false;
        }

        foreach (var path in PublicEntrance.PreserveColliders)
            if (Find(path) == null) return false;
        var door = Find(NativeSceneSwap.BuildingPath + "/StaticDoor");
        if (door == null || door.GetComponent<Il2CppScheduleOne.Doors.StaticDoor>() == null) return false;

        foreach (var path in PublicEntrance.DisableColliders)
        {
            var expected = Expected(path);
            var collider = MatchingCollider(Find(path), expected.Kind);
            if (collider == null) return false;
            _journal.Add((collider, collider.enabled));
            collider.enabled = false;
        }
        return true;
    }

    private void CreateLeaves()
    {
        _south = Leaf("sliding-south");
        _north = Leaf("sliding-north");
        Floor();
    }

    private Transform Leaf(string name)
    {
        var leaf = GameObject.CreatePrimitive(PrimitiveType.Cube);
        leaf.name = name;
        leaf.transform.SetParent(_sink.Root, false);
        leaf.transform.localScale = new Vector3(0.08f, PublicEntrance.LeafHeight, 0.96f);
        var renderer = leaf.GetComponent<Renderer>();
        if (renderer != null) renderer.sharedMaterial = Paint(new Color(0.55f, 0.52f, 0.48f));
        return leaf.transform;
    }

    private void Floor()
    {
        foreach (var box in PublicEntrance.CreateInterior())
        {
            var child = GameObject.CreatePrimitive(PrimitiveType.Cube);
            child.name = box.Name;
            child.transform.SetParent(_sink.Root, false);
            child.transform.localPosition = new Vector3(box.X, box.Y, box.Z);
            child.transform.localScale = new Vector3(box.Width, box.Height, box.Depth);
            var renderer = child.GetComponent<Renderer>();
            if (renderer != null) renderer.sharedMaterial = Paint(box.Style == 0
                ? new Color(0.72f, 0.68f, 0.60f) : new Color(0.78f, 0.74f, 0.66f));
        }
    }

    private Material Paint(Color color)
    {
        var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
        var material = new Material(shader);
        material.color = color;
        _materials.Add(material);
        return material;
    }

    private void HideDoorMesh()
    {
        foreach (var suffix in new[] { "/townhall/Door", "/townhall/Door/Glass", "/townhall/Door/Quad" })
        {
            var renderer = Find(NativeSceneSwap.BuildingPath + suffix)?.GetComponent<MeshRenderer>()
                ?? throw new InvalidOperationException("Native door contribution missing: " + suffix);
            _renderers.Add((renderer, renderer.enabled, renderer.forceRenderingOff));
            renderer.forceRenderingOff = true;
        }
        MelonLogger.Msg("TownHallInterior: three exact door contributions hidden (including distant billboard).");
    }

    private void SuppressPlayerKnock()
    {
        var doorObject = Find(NativeSceneSwap.BuildingPath + "/StaticDoor");
        var door = doorObject?.GetComponent<Il2CppScheduleOne.Doors.StaticDoor>();
        if (door == null) return;
        _nativeDoor = door; // Restore this exact instance, never a new scene's same-named door.
        _savedCanKnock = door.CanKnock;
        _savedUsable = door.Usable;
        _doorFlagsSaved = true;
        door.CanKnock = false;
        door.Usable = false;
        var interaction = door.IntObj;
        if (interaction != null)
        {
            _intObj = interaction.gameObject;
            _intObjWasActive = _intObj.activeSelf;
            _intObj.SetActive(false);
        }
        foreach (var renderer in doorObject!.GetComponentsInChildren<Renderer>(true))
        {
            _renderers.Add((renderer, renderer.enabled, renderer.forceRenderingOff));
            renderer.enabled = false;
            renderer.forceRenderingOff = true;
        }
        MelonLogger.Msg("TownHallInterior: player knock on Jen's door suppressed.");
    }


    private bool PlayerAtDoor()
    {
        var player = Player.Local;
        if (player == null) return false;
        var p = player.transform.position;
        return PublicEntrance.WantsDoorOpen(p.x, p.y, p.z);
    }

    private void Restore()
    {
        _cleanup ??= CreateCleanup();
        _disposed = _cleanup.Run((step, ex) => MelonLogger.Warning("TownHallInterior hall restore pending (" + step + "): " + ex.Message));
        if (!_disposed) return;
        _journal.Clear();
        _renderers.Clear();
        _materials.Clear();
        _nativeDoor = null;
        _intObj = null;
        _doorFlagsSaved = false;
    }

    private CleanupJournal CreateCleanup()
    {
        var cleanup = new CleanupJournal();
        cleanup.Add("furniture", () =>
        {
            _furnishings?.Dispose();
            if (_furnishings != null && !_furnishings.CleanupComplete)
                throw new InvalidOperationException("Furniture cleanup has pending steps");
            _furnishings = null;
        });
        cleanup.Add("facade", () =>
        {
            _facade?.Dispose();
            if (_facade != null && !_facade.CleanupComplete)
                throw new InvalidOperationException("Facade restoration has pending steps");
            _facade = null;
        });
        for (int i = _journal.Count - 1; i >= 0; i--)
        {
            var entry = _journal[i];
            cleanup.Add("native collider", () => { if (entry.Collider != null) entry.Collider.enabled = entry.Enabled; });
        }
        for (int i = _renderers.Count - 1; i >= 0; i--)
        {
            var entry = _renderers[i];
            cleanup.Add("native door renderer", () =>
            {
                if (entry.Renderer == null) return;
                entry.Renderer.forceRenderingOff = entry.ForcedOff;
                entry.Renderer.enabled = entry.Enabled;
            });
        }
        if (_doorFlagsSaved)
        {
            cleanup.Add("native CanKnock", () => { if (_nativeDoor != null) _nativeDoor.CanKnock = _savedCanKnock; });
            cleanup.Add("native Usable", () => { if (_nativeDoor != null) _nativeDoor.Usable = _savedUsable; });
        }
        cleanup.Add("native interaction", () => { if (_intObj != null) _intObj.SetActive(_intObjWasActive); });
        foreach (var material in _materials)
            cleanup.Add("owned hall material", () => { if (material != null) UnityEngine.Object.Destroy(material); });
        return cleanup;
    }

    private static NativeColliderObservation Expected(string path)
    {
        foreach (var candidate in NativeSceneSwap.Candidates)
            if (candidate.Path == path) return candidate;
        throw new InvalidOperationException(path);
    }

    private static Collider? MatchingCollider(GameObject? go, string kind)
    {
        if (go == null) return null;
        Collider? found = kind switch
        {
            "BoxCollider" => go.GetComponent<BoxCollider>(),
            "MeshCollider" => go.GetComponent<MeshCollider>(),
            _ => null,
        };
        return found;
    }

    private static int ColliderCount(GameObject go)
    {
        int count = 0;
        if (go.GetComponent<BoxCollider>() != null) count++;
        if (go.GetComponent<MeshCollider>() != null) count++;
        if (go.GetComponent<CapsuleCollider>() != null) count++;
        if (go.GetComponent<SphereCollider>() != null) count++;
        return count;
    }

    private static int CountGuid(string guid)
    {
        int count = 0;
        foreach (var building in UnityEngine.Object.FindObjectsOfType<NPCEnterableBuilding>())
            if (building != null && string.Equals(building.BakedGUID, guid, StringComparison.OrdinalIgnoreCase))
                count++;
        return count;
    }

    internal static GameObject? Find(string path)
    {
        var parts = path.Split('/');
        var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        foreach (var root in scene.GetRootGameObjects())
        {
            var found = Search(root.transform, parts);
            if (found != null) return found.gameObject;
        }
        return null;
    }

    private static Transform? Search(Transform node, string[] parts)
    {
        if (node.name == parts[0])
        {
            var rest = Match(node, parts, 0);
            if (rest != null) return rest;
        }
        for (int i = 0; i < node.childCount; i++)
        {
            var found = Search(node.GetChild(i), parts);
            if (found != null) return found;
        }
        return null;
    }

    private static Transform? Match(Transform node, string[] parts, int index)
    {
        if (node.name != parts[index]) return null;
        if (index == parts.Length - 1) return node;
        for (int i = 0; i < node.childCount; i++)
        {
            var found = Match(node.GetChild(i), parts, index + 1);
            if (found != null) return found;
        }
        return null;
    }
}
