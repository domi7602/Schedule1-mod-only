using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace TownHallInterior;

public sealed record FurniturePart
{
    public string SourcePath { get; init; } = "";
    public string MeshName { get; init; } = "";
    public int SourceVertexCount { get; init; }
    public int FirstSubMesh { get; init; }
    public bool IsStaticBatch { get; init; }
    public double[] SourceBoundsMin { get; init; } = Array.Empty<double>();
    public double[] SourceBoundsMax { get; init; } = Array.Empty<double>();
    public string[] MaterialNames { get; init; } = Array.Empty<string>();
    public double[][] Vertices { get; init; } = Array.Empty<double[]>();
    public int[][] Submeshes { get; init; } = Array.Empty<int[]>();
}

public sealed record FurnitureAsset
{
    public string Key { get; init; } = "";
    public double[] BoundsMin { get; init; } = Array.Empty<double>();
    public double[] BoundsMax { get; init; } = Array.Empty<double>();
    public FurniturePart[] Parts { get; init; } = Array.Empty<FurniturePart>();
}

public sealed record FurnitureDocument
{
    public int Schema { get; init; }
    public string LevelSha256 { get; init; } = "";
    public FurnitureAsset[] Assets { get; init; } = Array.Empty<FurnitureAsset>();
}

public sealed record FurniturePlacement(string Name, string Key, float X, float Y, float Z, float Yaw, bool Solid);

// Pure decorative layout. Accepted floor, stairs and entrance collision stay separate.
public static class FurniturePlan
{
    public static bool RequiresStableBounds(string key, FurniturePart part)
    {
        // Only material identity is borrowed from the two potentially moving hands.
        const string clock = "@Businesses/PostOffice/Interior/Wall Clock/";
        bool hand = key == "clock" && (part.SourcePath == clock + "Min/MinuteHand" || part.SourcePath == clock + "Hour/HourHand");
        return key == "door-frame" || (part.IsStaticBatch && !hand);
    }

    public static IReadOnlyList<FurniturePlacement> Create(FurnitureDocument document)
    {
        var required = new[] { "desk", "chair", "cabinet", "computer", "plant", "bin", "clock", "door-frame" };
        if (required.Any(key => document.Assets.Count(a => a.Key == key) != 1))
            throw new InvalidOperationException("Reception asset set is incomplete");
        float floor = PublicEntrance.FloorTop;
        float desktop = floor + (float)document.Assets.Single(a => a.Key == "desk").BoundsMax[1];
        var p = new List<FurniturePlacement>();
        void Add(string name, string key, float x, float y, float z, float yaw, bool solid = true) =>
            p.Add(new FurniturePlacement(name, key, x, y, z, yaw, solid));
        for (int i = 0; i < 2; i++)
        {
            float z = 33.8f + i * 2.2f;
            Add("reception-desk-" + i, "desk", 60f, floor, z, 180);
            Add("staff-chair-" + i, "chair", 61.2f, floor, z - .35f, 180);
            Add("reception-computer-" + i, "computer", 60f, desktop, z - .35f, 180, false);
            Add("reception-plant-" + i, "plant", 60f, desktop, z + .55f, 0, false);
        }
        for (int i = 0; i < 4; i++)
        {
            Add("waiting-west-" + i, "chair", 55.7f, floor, 24f + i * 1.1f, 0);
            Add("waiting-east-" + i, "chair", 58.5f, floor, 24f + i * 1.1f, 180);
        }
        Add("files-north-a", "cabinet", 61.8f, floor, 38.8f, 180);
        Add("files-north-b", "cabinet", 61.8f, floor, 39.7f, 180);
        Add("forms-desk", "desk", 56.8f, floor, 39.4f, 90);
        Add("forms-chair-a", "chair", 56.2f, floor, 38f, 270);
        Add("forms-chair-b", "chair", 57.3f, floor, 38f, 270);
        Add("forms-plant", "plant", 56.3f, desktop, 39.4f, 0, false);
        Add("waiting-bin", "bin", 56f, floor, 28.8f, 0);
        Add("reception-bin", "bin", 61.8f, floor, 32.5f, 0);
        Add("hall-clock", "clock", 58.8f, 3.3f, 40.377f, 180, false);
        Add("raised-native-frame", "door-frame", 54.3f, (float)FacadePortal.Minimum[1], 31f, 0, false);
        return p;
    }

    public static FurnitureAsset PrepareAsset(FurnitureAsset asset)
    {
        if (asset.Key != "door-frame") return asset;
        // Exact pinned frame: old inner header Y=2.1 and inner half-width Z=.525.
        // Translate the header and side columns; preserve moulding thickness and UVs.
        double rise = PublicEntrance.PortalTop - FacadePortal.Minimum[1] - 2.1;
        double widen = (FacadePortal.Maximum[2] - FacadePortal.Minimum[2]) / 2 + .01 - .525;
        var parts = asset.Parts.Select(p => p with
        {
            Vertices = p.Vertices.Select(v =>
        {
            var copy = (double[])v.Clone();
            if (copy[1] > 1) copy[1] += rise;
            copy[2] += Math.Sign(copy[2]) * widen;
            return copy;
        }).ToArray()
        }).ToArray();
        var vertices = parts.SelectMany(p => p.Vertices).ToArray();
        return asset with
        {
            Parts = parts,
            BoundsMin = Enumerable.Range(0, 3).Select(i => vertices.Min(v => v[i])).ToArray(),
            BoundsMax = Enumerable.Range(0, 3).Select(i => vertices.Max(v => v[i])).ToArray()
        };
    }

    public static FurnitureDocument Read(byte[] bytes)
    {
        if (bytes.Length > 12_000_000) throw new InvalidOperationException("Furniture byte budget exceeded");
        var document = JsonSerializer.Deserialize<FurnitureDocument>(bytes,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
            ?? throw new InvalidOperationException("Furniture document missing");
        if (document.Schema != 1 || document.LevelSha256 != FacadePortal.LevelSha256 ||
            document.Assets == null || document.Assets.Length is < 1 or > 12)
            throw new InvalidOperationException("Unrecognized furniture extraction or game version");
        var keys = new HashSet<string>(StringComparer.Ordinal);
        int vertexCount = 0;
        foreach (var asset in document.Assets)
        {
            if (asset == null || string.IsNullOrWhiteSpace(asset.Key) || !keys.Add(asset.Key) ||
                asset.Parts == null || asset.Parts.Length is < 1 or > 12)
                throw new InvalidOperationException("Invalid furniture asset identity/parts");
            CheckBounds(asset.BoundsMin, asset.BoundsMax);
            var paths = new HashSet<string>(StringComparer.Ordinal);
            foreach (var part in asset.Parts)
            {
                if (part == null || string.IsNullOrWhiteSpace(part.SourcePath) ||
                    part.SourcePath.Split('/').Any(s => string.IsNullOrWhiteSpace(s) || s is "." or "..") ||
                    !paths.Add(part.SourcePath) || string.IsNullOrWhiteSpace(part.MeshName) ||
                    part.SourceVertexCount < 3 || part.FirstSubMesh < 0)
                    throw new InvalidOperationException("Invalid furniture source identity");
                FacadePortal.ValidateMesh(new FacadeMesh { Vertices = part.Vertices, Submeshes = part.Submeshes });
                CheckBounds(part.SourceBoundsMin, part.SourceBoundsMax);
                if (part.MaterialNames == null || part.MaterialNames.Length != part.Submeshes.Length ||
                    part.MaterialNames.Any(string.IsNullOrWhiteSpace) || part.Submeshes.All(s => s.Length == 0))
                    throw new InvalidOperationException("Invalid furniture material slots");
                vertexCount += part.Vertices.Length;
                if (vertexCount > 30000) throw new InvalidOperationException("Furniture vertex budget exceeded");
            }
            var vertices = asset.Parts.SelectMany(p => p.Vertices).ToArray();
            for (int axis = 0; axis < 3; axis++)
            {
                if (Math.Abs(vertices.Min(v => v[axis]) - asset.BoundsMin[axis]) > .0001 ||
                    Math.Abs(vertices.Max(v => v[axis]) - asset.BoundsMax[axis]) > .0001 ||
                    asset.BoundsMax[axis] - asset.BoundsMin[axis] > 6)
                    throw new InvalidOperationException("Furniture geometry/bounds mismatch: " + asset.Key);
            }
            if (Math.Abs(asset.BoundsMin[1]) > .0001 ||
                Math.Abs(asset.BoundsMin[0] + asset.BoundsMax[0]) > .0001 ||
                Math.Abs(asset.BoundsMin[2] + asset.BoundsMax[2]) > .0001)
                throw new InvalidOperationException("Furniture pivot must be bottom center: " + asset.Key);
        }
        return document;
    }

    private static void CheckBounds(double[] min, double[] max)
    {
        if (min == null || max == null || min.Length != 3 || max.Length != 3)
            throw new InvalidOperationException("Missing furniture bounds");
        for (int i = 0; i < 3; i++)
            if (!double.IsFinite(min[i]) || !double.IsFinite(max[i]) || max[i] < min[i])
                throw new InvalidOperationException("Invalid furniture bounds");
    }

    public static IReadOnlyList<RoomBox> CreateShell()
    {
        var boxes = new List<RoomBox>();
        var skin = PublicEntrance.CreateInterior();
        var west = skin.Single(b => b.Name == "inner-west-south");
        var east = skin.Single(b => b.Name == "inner-east");
        foreach (var slab in RoomPlan.Create().Where(b => b.Name.StartsWith("upper-")))
        {
            var x1 = Math.Max(west.X + west.Width / 2, slab.X - slab.Width / 2);
            var x2 = Math.Min(east.X - east.Width / 2, slab.X + slab.Width / 2);
            var z1 = Math.Max(21.6f, slab.Z - slab.Depth / 2);
            var z2 = Math.Min(40.4f, slab.Z + slab.Depth / 2);
            boxes.Add(new RoomBox("ceiling-" + slab.Name, (x1 + x2) / 2, 4.44f, (z1 + z2) / 2,
                x2 - x1, .08f, z2 - z1, false, 1));
        }
        foreach (var wall in PublicEntrance.CreateInterior().Where(b => b.Name.StartsWith("inner-") && b.Name != "inner-lintel"))
            boxes.Add(wall with { Name = "crown-" + wall.Name, Y = 4.34f, Height = .28f, Solid = false });
        return boxes;
    }
}
