using System;
using System.Collections.Generic;

namespace TownHallInterior;

// Shared entrance geometry and motion policy; native mutation remains in the runtime host.
public static class PublicEntrance
{
    public const float SlideSeconds = 0.75f;
    public const float SensorRadius = 1.2f;
    // Shared visual/collision opening height; a design coordinate, not a player measurement.
    public const float PortalTop = 4.55f;
    public const float LeafHeight = 3.2f;
    public const float LeafCenterY = PortalTop - LeafHeight / 2;
    public const float LintelHeight = 0.3f;
    // These are owned geometry coordinates, NOT measured native floor/player heights.
    public const float FloorCenterY = 1.48f, FloorThickness = 0.1f;
    public const float FloorTop = FloorCenterY + FloorThickness / 2;

    public static IReadOnlyList<RoomBox> CreateInterior() => new[]
    {
        new RoomBox("public-floor", 58.7f, FloorCenterY, 31f, 7.4f, FloorThickness, 18.8f, true, 0),
        new RoomBox("inner-west-south", 54.85f, 2.85f, 25.6f, 0.2f, 2.7f, 8.8f, true, 1),
        new RoomBox("inner-west-north", 54.85f, 2.85f, 36.4f, 0.2f, 2.7f, 8.8f, true, 1),
        new RoomBox("inner-lintel", 54.85f, PortalTop + LintelHeight / 2, 31f, 0.2f, LintelHeight, 1.92f, true, 1),
        new RoomBox("inner-east", 62.55f, 2.85f, 31f, 0.2f, 2.7f, 18.8f, true, 1),
        new RoomBox("inner-south", 58.7f, 2.85f, 21.5f, 7.4f, 2.7f, 0.2f, true, 1),
        new RoomBox("inner-north", 58.7f, 2.85f, 40.5f, 7.4f, 2.7f, 0.2f, true, 1),
    };
    public static readonly string[] DisableColliders =
    {
        NativeSceneSwap.BuildingPath + "/townhall/Walls",
        NativeSceneSwap.BuildingPath + "/Cube",
        NativeSceneSwap.BuildingPath + "/townhall/Door/Quad",
        NativeSceneSwap.BuildingPath + "/townhall/UpperBrickTrim",
    };
    public static readonly string[] PreserveColliders =
    {
        NativeSceneSwap.BuildingPath + "/townhall/UpperBrickTrim",
        NativeSceneSwap.BuildingPath + "/townhall/LowerBrickTrim",
        NativeSceneSwap.BuildingPath + "/StaticDoor",
    };

    public static bool ColliderSwapAllowed(NativeSceneInspection inspection) =>
        inspection.IdentityAndGeometryMatch && !inspection.CanPublish;

    public static bool WantsDoorOpen(float x, float y, float z)
    {
        // Keep both approaches and the occupied threshold, not the entire public hall.
        return x >= 51.6f && x <= 56.4f && z >= 29.2f && z <= 32.8f && y >= 0.8f && y <= 4.2f;
    }

    public static float MoveLeaf(float current, bool occupied, float deltaSeconds)
    {
        if (float.IsNaN(current) || float.IsInfinity(current)) current = 0f;
        var target = occupied ? 1f : 0f;
        var step = Math.Max(0f, deltaSeconds) / SlideSeconds;
        if (current < target) return Math.Min(target, current + step);
        return Math.Max(target, current - step);
    }
}
